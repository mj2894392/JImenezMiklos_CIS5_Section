
/* 
 * File: Gaddis_8th_5_11_population
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 8:16 PM
 * Purpose: Population Calculator
 */


#include <iostream>
using namespace std;
int main()

{
    float num_org,
          dly_pop_inc;
         

    int days;

    cout << "How many organisms? ";

    while (!(cin >> num_org) || num_org < 2)
    { cout << "Number must be higher than 2, try again.";
        cout << "How many organisms? ";
        cin.clear();
        cin.ignore(1000, '\n'); }

    cout << "Enter average daily population increase (%)";

    while (!(cin >> dly_pop_inc) || dly_pop_inc < 0)
    { cout << "Number must be great than 0, try again." << "\n";
        cout << "Enter average daily population increase (ex. 5=5%)"; 
        cin.clear();
        cin.ignore(1000, '\n'); }

    dly_pop_inc *= .01;

    cout << "How many days?";

    while(!(cin >> days) || days < 1)
    { cout << "Number must be above 1, try again.\n"
             << "How many days?";
        cin.clear();
        cin.ignore(1000, '\n'); }

    for(int i = 0; i < days; i++)
    {cout << "Daily population size" << (i + 1);
        cout << ": " << num_org << endl;  
        num_org += (num_org * dly_pop_inc); }
    
    return 0;
}


