

/* 
 * File: Review Homework
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 6:02 PM
 * Purpose: Display answer to the code in 7.6
 */

#include <iostream>
using namespace std;

int main ()
{
    cout << "The output is:" << "\n"
            "1" << "\n"
            "2" << "\n"
            "3" << "\n"
            "4" << "\n"
            "5" << "\n";
           
return 0;
}
