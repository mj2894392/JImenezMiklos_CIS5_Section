
/* 
 * File: Gaddis_8th_7_6_Rain_or_Shine
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 8:16 PM
 * Purpose: Find the highest number of days with rain
 */



#include <iostream>
#include <fstream>
using namespace std;

const int row = 3, 
          clmns = 30;

string wthr_typ[row]  = {"Rainy", "Cloudy", "Sunny"};
string months[row]         = {"June", "July", "August"};
char day_nm[row]= {'R', 'C', 'S'};

void gt_file(char[][clmns], string);
void show_mnth(const char[][clmns], int);
void show_day(const char[][clmns], int);
void show_hghst(const char[][clmns]);

int main()
{
    char wthr_cnd[row][clmns];

    gt_file(wthr_cnd, "RainOrShine.txt");

    for (int letter = 0; letter < row; letter++)
        show_day(wthr_cnd, letter);
    
    for (int i = 0; i < row; i++)
        show_mnth(wthr_cnd, i);

    show_hghst(wthr_cnd);

    cout << endl;

    return 0;
} // End int main()

void gt_file(char array[][clmns], string file_nm)
{
    ifstream inputFile;

    inputFile.open(file_nm);

    for(int row = 0; row < row; row++)
    {
        for(int col = 0; col < clmns; col++)
            inputFile >> array[row][col];
    }

    inputFile.close();
}

void show_day(const char array[][clmns], int i)
{
    int total;
    for (int row = 0; row < row; row++)
    { 
        total = 0;
        for (int col = 0; col < clmns; col++)
            if (array[row][col] == day_nm[i]) { total++; }

        cout << "Total "
             << wthr_typ[i]
             << " days for "
             << months[row]
             << " = "
             << total
             << endl;
    }
    cout << endl;
}

void show_mnth(const char array[][clmns], int i)
{
    int total = 0;
    for(int row = 0; row < row; row++)
    {
        for(int col = 0; col < clmns; col++)
            if(array[row][col] == day_nm[i]) { total++; }
    }

    cout << "Total " << wthr_typ[i] << " days for all months; "
         << total << endl;

}

void show_hghst(const char array[][clmns])
{
    int sum;
    int mst_rain_day[row];
    
    for (int row = 0; row < row; row++)
    {
        sum = 0;
        for (int col = 0; col < clmns; col++)
            if (array[row][col] == 'R') { sum++; }
            
        mst_rain_day[row] = sum;
    }

    cout << endl;


    int hghst_rain = mst_rain_day[0];
    string hghst_rn_nm = months[0];

    for(int i = 1; i < row; i++)
    {
        if(mst_rain_day[i] > hghst_rain)
        {
            hghst_rain = mst_rain_day[i];
            hghst_rn_nm = months[i];
        } 
        else if(mst_rain_day[i] == hghst_rain)
        {
            hghst_rain = mst_rain_day[i];
            hghst_rn_nm += ", ";
            hghst_rn_nm += months[i];
        }
            
    }

    cout << hghst_rn_nm << " had the most rainy days, " << "with "
         << hghst_rain << " days." << endl;
}