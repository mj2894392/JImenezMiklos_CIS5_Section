/* 
 * File: Review Homework 1
 * Author: Miklos Jimenez
 *Created on March,05 2021, 4:35 PM
 * Purpose: Answer question 4.10
 */ 
 
#include <iostream>
#include <iomanip>
using namespace std;
 int main ()
{
  int sales;
  const int nmchck = 50000;
  cout << "Please type the sales amount (dollars)" << endl;
  cin >> sales;
  if (sales > nmchck)
  {
    const float rate = 0.25;
    unsigned bns = 250;
    cout << "Commission rate is:" << rate << "\n";
    cout << "Bonus is:" << bns << "\n";
  }  
  
  return 0;
}



