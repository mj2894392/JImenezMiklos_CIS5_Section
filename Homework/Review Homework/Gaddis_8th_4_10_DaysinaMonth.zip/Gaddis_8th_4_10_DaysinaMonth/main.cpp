
/* 
 * File: Gaddis_8th_4_10_convert_currency
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 8:16 PM
 * Purpose: Show how many days in the month of a year
 */


#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    int month;
    int year;
    int days;
   
    cout << "Please enter a year" << endl;
    cin >> year;
    cout << "Please enter a month (1-12)" << endl;
    cin >> month;
   
    {switch (month)
     {case 1:
      case 3:
      case 5:
      case 7:
      case 8:
      case 10:
      case 12: days = 31;
     
      break;
      
      case 4:
      case 6:
      case 9:
      case 11: days = 30;
        
        break;
        
        case 2:
                   if (year % 100 == 0)
                {if (year % 400 == 0)
                        days = 29;
                    else
                        days = 28;}
                else if (year % 100 != 0)
                {if (year % 4 == 0)
                        days = 29;
                    else
                        days = 28;}
    }
    }
      cout << "There are " << days << " days in month #" << month << " of the \n"
           << "year " << year << endl;
    return 0;
}
          
          
    
