
/* 
 * File: Gaddis_8th_6_7_Celsius_Temperature_Table
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 8:16 PM
 * Purpose: Celsius Temperature Table
 */

#include <iostream>
using namespace std;

//function prototype
float clss(float);

int main()
{const int mn_Tmp = 0,
           mx_Tmp = 20;
float cnvrtC;

    cout << "Fahrenheit      Celsius\n";
    cout << "-----------------------------------|\n";

    for (int cnvrtF = mn_Tmp; cnvrtF <= mx_Tmp; cnvrtF++)
    { cnvrtC = clss(cnvrtF);
      cout << cnvrtF << "             ";
      cout << cnvrtC << endl; }
    
return 0;
}

// function
float clss(float cnvrtF)
{ return (5.0/9.0) * (cnvrtF - 32.0);
}


