/* 
 * File: main.cpp
 * Author: Miklos Jimenez
 *Created on March,05 2021, 4:35 PM
 * Purpose: Takes user inputted character and converts into its ASCII code form 
 */

#include <iostream>
using namespace std;
int main()
{
   char letter; 
    cout << "Enter a letter" << endl;
    cin >> letter;
    cout<< static_cast<int>(letter) << endl;
    return 0;
}


