

/* 
 * File: Gaddis_8th_3_12_convert_temperature
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 8:16 PM
 * Purpose: Convert Celsius to Fahrenheit
 */

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    float clss; 
    float frnht;
    
    
    cout << "Please enter temperature in Celsius" << endl;
    cin >> clss;
    frnht = 9.0/5 * clss + 32;
    cout << clss << " degrees Celsius is: " << frnht << "\n" 
            << "in degrees Fahrenheit." << endl;
    
 return 0;
}

