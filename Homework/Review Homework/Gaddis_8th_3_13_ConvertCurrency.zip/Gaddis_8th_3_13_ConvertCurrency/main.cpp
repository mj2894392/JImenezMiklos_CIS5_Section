
/* 
 * File: Gaddis_8th_3_13_convert_currency
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 8:16 PM
 * Purpose: Convert Dollar Yen and Euro
 */


#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
   const float yen = 108.93;
   const float euro = .84;
   int dollar;
   
   cout << "How many dollars?" << endl;
   cin >> dollar;
 
   float cnvrtyn = dollar * yen;
   float cnvrter = dollar * euro;
  
  cout << "Dollar to Yen: " << cnvrtyn << "\n"
       << "Dollar to Euro: " << cnvrter << endl;
   
 return 0;
}



