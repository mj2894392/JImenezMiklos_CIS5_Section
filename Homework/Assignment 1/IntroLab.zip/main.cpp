
/*

 * File: main.cpp

 * Author: Miklos Jimenez
 
 * Created on February 23, 2021, 11:00 PM

 * Purpose: Output 'Hello World' 

 */

#include <iostream>

using namespace std;

int main()
{
   cout<<"Hello World";

   return 0;
}

