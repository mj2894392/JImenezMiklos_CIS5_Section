

/* 
 * File: Review Homework
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 6:02 PM
 * Purpose: Create a function prototype
 *
 *I just ended up writing a program anyway, 
 *the answer is void timesTen(unsigned int);
 */

#include <iomanip>
#include <iostream>
using namespace std;

//Function Prototype
int timesTen(unsigned int);

int main ()
{
 int nmbr;
  cout << "Enter a number" << endl;
  cin >> nmbr;
  timesTen (nmbr);  
    
 return 0;
}

timesTen (unsigned int nmbr)
{
  int prdct = 10;    
   cout << nmbr * prdct; 
   
}
