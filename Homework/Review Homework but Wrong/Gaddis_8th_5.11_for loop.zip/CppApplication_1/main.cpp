

/* 
 * File: Review Homework
 * Author: Miklos Jimenez
 * Created on March 6, 2021, 6:02 PM
 * Purpose: Use the for loop to display every fifth number 0-100
 */

#include <iomanip>
#include <iostream>
using namespace std;

int main ()
{
    const char incrmnt = 5;
    const char lmt = 100;
    char nmbr = 0;
    int number;
     
     for (number = nmbr; number <= lmt; number += incrmnt)
      cout << number << "\n";
    
    return 0;
}

