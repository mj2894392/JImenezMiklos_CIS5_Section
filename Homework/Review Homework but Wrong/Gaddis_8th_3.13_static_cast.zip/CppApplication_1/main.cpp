/* 
 * File: main.cpp
 * Author: Miklos Jimenez
 *Created on March,05 2021, 4:35 PM
 * Purpose: Answer question 3.13
 */ 
 
#include <iostream>
using namespace std;
 int main ()
{
  cout << "In this order: 9, 9.5, then 9" << endl;
  
  return 0;
}



